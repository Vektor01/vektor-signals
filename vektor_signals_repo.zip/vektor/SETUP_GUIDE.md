# VEKTOR SIGNALS — LAUNCH PLAYBOOK
## Complete Setup Guide — Do These Steps In Order

---

## ⏱ ESTIMATED TIME: 90 minutes total

---

## STEP 1 — GET YOUR TWO API KEYS (15 min)

### CoinGecko API Key (Free)
1. Go to: https://www.coingecko.com/en/api
2. Click "Get Demo API Key" — no credit card needed
3. Verify your email
4. Copy your API key — save it somewhere safe
   Example: `CG-xxxxxxxxxxxxxxxxxxxx`

### Anthropic API Key (Pay as you go — costs pennies per day)
1. Go to: https://console.anthropic.com
2. Sign up / log in
3. Go to "API Keys" → "Create Key"
4. Copy your API key — save it
   Example: `sk-ant-api03-xxxxxxxxxxxxxxxxxxxx`
5. Add $5 credit to start — daily signal generation costs ~$0.02/day

---

## STEP 2 — SET UP RESEND FOR EMAIL DELIVERY (10 min)

1. Go to: https://resend.com — sign up free
2. Add your domain: vektorsignals.com
3. Follow their DNS verification (add 2-3 DNS records in your domain registrar)
4. Once verified, go to API Keys → Create API Key
5. Save your Resend API key: `re_xxxxxxxxxxxxxxxxxxxx`
6. In Resend, go to Domains and confirm vektorsignals.com is verified ✅

---

## STEP 3 — RUN SUPABASE SCHEMA (5 min)

1. Go to your Supabase project dashboard
2. Click "SQL Editor" in the left sidebar
3. Click "New Query"
4. Copy the entire contents of `supabase_schema.sql`
5. Paste it and click "Run"
6. You should see: subscribers, signal_logs, email_log tables created ✅
7. Go to Settings → API → copy:
   - Project URL: `https://xxxx.supabase.co`
   - service_role key (NOT the anon key — the service_role one)

---

## STEP 4 — CREATE GITHUB REPO & ADD SECRETS (15 min)

1. Go to GitHub.com → New Repository
2. Name it: `vektor-signals` (private repo)
3. Upload all files from this folder to the repo

4. Go to your repo → Settings → Secrets and variables → Actions
5. Add these secrets one by one (click "New repository secret"):

   | Secret Name          | Value                              |
   |---------------------|------------------------------------|
   | ANTHROPIC_API_KEY   | your Anthropic key                 |
   | COINGECKO_API_KEY   | your CoinGecko key                 |
   | SUPABASE_URL        | https://xxxx.supabase.co           |
   | SUPABASE_SERVICE_KEY| your Supabase service_role key     |
   | RESEND_API_KEY      | your Resend key                    |
   | STRIPE_SECRET_KEY   | your Stripe secret key (sk_live_xx)|
   | STRIPE_WEBHOOK_SECRET| from Stripe webhook setup (step 5)|

---

## STEP 5 — SET UP STRIPE WEBHOOK (15 min)

1. Go to Stripe Dashboard → Developers → Webhooks
2. Click "Add endpoint"
3. Endpoint URL: `https://YOUR-NETLIFY-SITE.netlify.app/.netlify/functions/stripe-webhook`
4. Select events to listen to:
   - ✅ checkout.session.completed
   - ✅ customer.subscription.deleted
   - ✅ customer.subscription.updated
   - ✅ invoice.payment_failed
5. Click "Add endpoint"
6. Copy the "Signing secret" → this is your STRIPE_WEBHOOK_SECRET

7. In your Netlify site:
   - Go to Site Settings → Environment Variables
   - Add: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, SUPABASE_URL, SUPABASE_SERVICE_KEY

8. Deploy the netlify/functions/stripe-webhook.js file to your Netlify repo

9. In stripe-webhook.js, replace the placeholder Price IDs:
   - Go to Stripe → Products → click each product → copy the Price ID
   - Replace `price_REPLACE_STANDARD_MONTHLY` etc with real IDs

---

## STEP 6 — TEST THE FULL PIPELINE (20 min)

### Test 1: Manual trigger
1. Go to your GitHub repo → Actions tab
2. Click "Vektor Daily Signals" workflow
3. Click "Run workflow" → "Run workflow"
4. Watch the logs — should complete in ~3 minutes
5. Check the Artifacts section — 4 PDFs should appear

### Test 2: Test email delivery
1. Add yourself to Supabase as a VIP subscriber:
   ```sql
   insert into subscribers (email, tier) values ('your@email.com', 'vip');
   ```
2. Run the workflow again manually
3. You should receive an email with 4 PDF attachments

### Test 3: Test Stripe webhook
1. Use Stripe's "Send test webhook" feature
2. Send a `checkout.session.completed` test event
3. Check Supabase — a new subscriber should appear

---

## STEP 7 — GO LIVE (10 min)

1. Upload your updated index.html to Netlify with the payment buttons
2. Make a test purchase using Stripe test mode
3. Confirm you receive the welcome email + PDFs
4. Switch Stripe to LIVE mode
5. Post to your crypto community — you're live 🚀

---

## DAILY SCHEDULE (Once Live)

```
06:30 GMT  — GitHub Actions triggers automatically
06:31      — Live prices fetched from CoinGecko
06:32      — Claude generates fresh signal analysis
06:33      — 4 PDFs built and named with today's date
06:34      — Emails sent to all active subscribers by tier
06:35      — Done. You're still asleep. ✅
```

---

## COSTS BREAKDOWN (Monthly)

| Service        | Cost           | Notes                          |
|---------------|----------------|--------------------------------|
| GitHub Actions | FREE           | 2,000 min/month free           |
| CoinGecko API  | FREE           | Demo tier is sufficient        |
| Anthropic API  | ~$0.60/month   | ~$0.02 per daily run           |
| Resend         | FREE           | 3,000 emails/month free        |
| Supabase       | FREE           | 500MB, 50,000 rows free        |
| Netlify        | FREE           | 100GB bandwidth free           |
| **TOTAL**      | **~$0.60/mo**  | Until you scale past free tiers|

---

## TROUBLESHOOTING

**GitHub Action fails:**
- Check Actions tab → click the failed run → read the error log
- Most common: missing secret, typo in secret name

**Emails not arriving:**
- Check Resend dashboard → Logs
- Confirm domain is verified in Resend
- Check spam folder

**Stripe webhook not firing:**
- Test it in Stripe Dashboard → Developers → Webhooks → your endpoint → Send test event
- Check Netlify Functions log

**CoinGecko rate limit:**
- Demo key allows 30 calls/minute — way more than we need (we use 1 call per day)

---

## SUPPORT

Need help? Message Mark directly or open an issue in the GitHub repo.
