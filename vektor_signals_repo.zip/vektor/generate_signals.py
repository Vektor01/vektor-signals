"""
VEKTOR SIGNALS — Daily Automation Orchestrator
Runs every morning at 06:30 GMT via GitHub Actions.
Flow: Fetch Prices → Generate Signal Copy via Claude → Build PDFs → Email Subscribers
"""

import os
import json
import requests
from datetime import datetime, timezone

# ── CONFIG ─────────────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]
COINGECKO_API_KEY = os.environ["COINGECKO_API_KEY"]
SUPABASE_URL      = os.environ["SUPABASE_URL"]
SUPABASE_KEY      = os.environ["SUPABASE_SERVICE_KEY"]
RESEND_API_KEY    = os.environ["RESEND_API_KEY"]

NOW = datetime.now(timezone.utc)
DATE_LABEL = NOW.strftime("%A %d %B %Y")
DATE_FILE  = NOW.strftime("%Y%m%d")
TIME_LABEL = NOW.strftime("%H:%M GMT")

# ── STEP 1: FETCH LIVE PRICES FROM COINGECKO ──────────────────────────────────
def fetch_prices():
    print("📡 Fetching live prices from CoinGecko...")
    ids = "bitcoin,ethereum,ripple,solana,binancecoin,hyperliquid"
    url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd&include_24hr_change=true"
    headers = {"x-cg-demo-api-key": COINGECKO_API_KEY}
    resp = requests.get(url, headers=headers, timeout=15)
    resp.raise_for_status()
    data = resp.json()

    prices = {
        "BTC":  {"price": data["bitcoin"]["usd"],         "change": data["bitcoin"]["usd_24h_change"]},
        "ETH":  {"price": data["ethereum"]["usd"],        "change": data["ethereum"]["usd_24h_change"]},
        "XRP":  {"price": data["ripple"]["usd"],          "change": data["ripple"]["usd_24h_change"]},
        "SOL":  {"price": data["solana"]["usd"],          "change": data["solana"]["usd_24h_change"]},
        "BNB":  {"price": data["binancecoin"]["usd"],     "change": data["binancecoin"]["usd_24h_change"]},
        "HYPE": {"price": data["hyperliquid"]["usd"],     "change": data["hyperliquid"]["usd_24h_change"]},
    }
    for k, v in prices.items():
        sign = "+" if v["change"] >= 0 else ""
        print(f"  {k}: ${v['price']:,.2f}  {sign}{v['change']:.1f}%")
    return prices


# ── STEP 2: GENERATE SIGNAL ANALYSIS VIA CLAUDE API ───────────────────────────
def generate_signals_claude(prices):
    print("\n🤖 Generating signal analysis via Claude...")

    price_block = "\n".join([
        f"- {k}: ${v['price']:,.4f}  ({'+' if v['change']>=0 else ''}{v['change']:.1f}% 24h)"
        for k, v in prices.items()
    ])

    prompt = f"""You are Vektor Signals, an elite crypto trading signal service.
Today is {DATE_LABEL}. Current prices:
{price_block}

Generate a daily signal analysis for all 6 assets. For each, provide:
- BIAS: one of [STRONG BUY, BUY, ACCUMULATE, NEUTRAL, CAUTION, REDUCE]
- RISK: one of [LOW, MEDIUM, MEDIUM-HIGH, HIGH, VERY HIGH]
- ENTRY_ZONE: price range string
- TARGET_1: price + % gain
- TARGET_2: price + % gain  
- STOP_LOSS: price + % loss
- RSI_ESTIMATE: number 0-100 based on recent price action
- STRUCTURE: 3-4 word market structure description
- TA: 2-3 sentence technical analysis (max 200 chars)
- CATALYST: 2-3 sentence catalyst/thesis (max 200 chars)
- SUMMARY_LINE: one punchy sentence about this asset today (max 100 chars)

Also generate:
- MACRO_SUMMARY: 1 sentence on today's macro context (max 150 chars)
- WILDCARD_INTRO: 1 sentence intro for the wild card report (max 150 chars)
- SESSION_THEME: 3-5 word theme for today (e.g. "Accumulation Before The Catalyst")

Respond ONLY in valid JSON, no markdown, no preamble. Format:
{{
  "session_theme": "...",
  "macro_summary": "...",
  "wildcard_intro": "...",
  "signals": {{
    "BTC": {{"bias":"...","risk":"...","entry_zone":"...","target_1":"...","target_2":"...","stop_loss":"...","rsi_estimate":"...","structure":"...","ta":"...","catalyst":"...","summary_line":"..."}},
    "ETH": {{...}},
    "XRP": {{...}},
    "SOL": {{...}},
    "BNB": {{...}},
    "HYPE": {{...}}
  }}
}}"""

    headers = {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
    }
    body = {
        "model": "claude-sonnet-4-5",
        "max_tokens": 2000,
        "messages": [{"role": "user", "content": prompt}]
    }
    resp = requests.post("https://api.anthropic.com/v1/messages",
                         headers=headers, json=body, timeout=60)
    resp.raise_for_status()

    raw = resp.json()["content"][0]["text"].strip()
    # Strip any accidental markdown fences
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    signals = json.loads(raw.strip())
    print(f"  Theme: {signals.get('session_theme')}")
    print(f"  Signals generated for: {list(signals['signals'].keys())}")
    return signals


# ── STEP 3: BUILD ALL PDFs ─────────────────────────────────────────────────────
def build_pdfs(prices, signals):
    print("\n📄 Building PDFs...")
    from generators.pdf_vip import build_vip_pdf
    from generators.pdf_wildcard import build_wildcard_pdf
    from generators.pdf_standard import build_standard_pdf
    from generators.pdf_macro import build_macro_pdf

    os.makedirs("outputs", exist_ok=True)

    vip_path      = f"outputs/vektor_vip_{DATE_FILE}.pdf"
    wildcard_path = f"outputs/vektor_wildcard_{DATE_FILE}.pdf"
    standard_path = f"outputs/vektor_standard_{DATE_FILE}.pdf"
    macro_path    = f"outputs/vektor_macro_{DATE_FILE}.pdf"

    build_vip_pdf(prices, signals, vip_path, DATE_LABEL, TIME_LABEL)
    print(f"  ✅ VIP: {vip_path}")

    build_wildcard_pdf(prices, signals, wildcard_path, DATE_LABEL, TIME_LABEL)
    print(f"  ✅ Wild Card: {wildcard_path}")

    build_standard_pdf(prices, signals, standard_path, DATE_LABEL, TIME_LABEL)
    print(f"  ✅ Standard: {standard_path}")

    build_macro_pdf(prices, signals, macro_path, DATE_LABEL, TIME_LABEL)
    print(f"  ✅ Macro: {macro_path}")

    return {
        "vip": vip_path,
        "wildcard": wildcard_path,
        "standard": standard_path,
        "macro": macro_path
    }


# ── STEP 4: FETCH SUBSCRIBERS FROM SUPABASE ───────────────────────────────────
def fetch_subscribers():
    print("\n👥 Fetching subscribers from Supabase...")
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json"
    }
    resp = requests.get(
        f"{SUPABASE_URL}/rest/v1/subscribers?select=email,tier,active&active=eq.true",
        headers=headers, timeout=15
    )
    resp.raise_for_status()
    subs = resp.json()
    print(f"  Found {len(subs)} active subscribers")
    by_tier = {"free": [], "standard": [], "vip": []}
    for s in subs:
        tier = s.get("tier", "free").lower()
        if tier in by_tier:
            by_tier[tier].append(s["email"])
    for tier, emails in by_tier.items():
        print(f"  {tier.upper()}: {len(emails)}")
    return by_tier


# ── STEP 5: SEND EMAILS VIA RESEND ────────────────────────────────────────────
def send_emails(subscribers, pdf_paths, signals):
    print("\n📧 Sending emails...")

    TIER_CONFIG = {
        "vip": {
            "subject": f"⚡ Vektor VIP Signals — {DATE_LABEL}",
            "pdfs": ["vip", "wildcard", "standard", "macro"],
            "preview": "Your full daily briefing: VIP signals, Wild Card picks, Standard report & Macro overview.",
        },
        "standard": {
            "subject": f"📊 Vektor Daily Signals — {DATE_LABEL}",
            "pdfs": ["standard", "macro"],
            "preview": "Your daily standard signals and macro overview are ready.",
        },
        "free": {
            "subject": f"🎯 Vektor Wild Card — {DATE_LABEL}",
            "pdfs": ["wildcard"],
            "preview": "Today's speculative Wild Card picks are ready.",
        },
    }

    results = {"sent": 0, "failed": 0}

    for tier, config in TIER_CONFIG.items():
        emails = subscribers.get(tier, [])
        if not emails:
            continue

        # Build PDF attachments
        attachments = []
        for key in config["pdfs"]:
            path = pdf_paths.get(key)
            if path and os.path.exists(path):
                import base64
                with open(path, "rb") as f:
                    encoded = base64.b64encode(f.read()).decode()
                attachments.append({
                    "filename": os.path.basename(path),
                    "content": encoded,
                    "type": "application/pdf"
                })

        theme = signals.get("session_theme", "Daily Signals")
        html_body = build_email_html(tier, theme, config["preview"], signals, DATE_LABEL)

        for email in emails:
            payload = {
                "from": "Vektor Signals <signals@vektorsignals.com>",
                "to": [email],
                "subject": config["subject"],
                "html": html_body,
                "attachments": attachments
            }
            resp = requests.post(
                "https://api.resend.com/emails",
                headers={"Authorization": f"Bearer {RESEND_API_KEY}", "Content-Type": "application/json"},
                json=payload, timeout=30
            )
            if resp.status_code in (200, 201):
                results["sent"] += 1
            else:
                print(f"  ❌ Failed to send to {email}: {resp.text}")
                results["failed"] += 1

    print(f"  ✅ Sent: {results['sent']}  ❌ Failed: {results['failed']}")
    return results


def build_email_html(tier, theme, preview, signals, date_label):
    tier_labels = {"vip": "⚡ VIP", "standard": "📊 Standard", "free": "🎯 Free"}
    tier_colors = {"vip": "#F5C842", "standard": "#4DC3FF", "free": "#7B2FBE"}
    color = tier_colors.get(tier, "#7B2FBE")
    label = tier_labels.get(tier, "")

    bullet_lines = ""
    for ticker, sig in signals.get("signals", {}).items():
        if tier == "free" and ticker not in ["BTC"]:
            continue  # Free tier only gets BTC preview
        bias = sig.get("bias", "")
        line = sig.get("summary_line", "")
        bullet_lines += f'<tr><td style="padding:6px 0;color:#9A94B8;font-size:13px;"><b style="color:#fff;">{ticker}</b> <span style="color:{color};">{bias}</span> — {line}</td></tr>'

    return f"""<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#080612;font-family:Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;margin:0 auto;background:#0F0C1E;border:1px solid #2A2240;">
  <tr><td style="padding:24px;border-bottom:1px solid #2A2240;">
    <span style="font-size:22px;font-weight:bold;color:#F5C842;">VEKTOR</span>
    <span style="font-size:22px;font-weight:bold;color:#fff;"> SIGNALS</span>
    <span style="background:{color};color:#000;font-size:11px;font-weight:bold;padding:3px 8px;border-radius:3px;margin-left:8px;">{label}</span>
    <p style="color:#6E688A;font-size:12px;margin:8px 0 0 0;">{date_label}</p>
  </td></tr>
  <tr><td style="padding:20px 24px;">
    <p style="color:#fff;font-size:15px;font-weight:bold;margin:0 0 4px 0;">"{theme}"</p>
    <p style="color:#9A94B8;font-size:13px;margin:0 0 20px 0;">{preview}</p>
    <table width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #2A2240;border-bottom:1px solid #2A2240;">
      {bullet_lines}
    </table>
    <p style="color:#6E688A;font-size:11px;margin:20px 0 0 0;">Your signal PDFs are attached to this email. Open them for full entry zones, targets, stop losses and analysis.</p>
  </td></tr>
  <tr><td style="padding:16px 24px;border-top:1px solid #2A2240;text-align:center;">
    <p style="color:#6E688A;font-size:10px;margin:0;">AI market analysis — educational purposes only. Not financial advice.<br>
    Vektor Signals — vektorsignals.com | <a href="{{{{unsubscribe}}}}" style="color:#7B2FBE;">Unsubscribe</a></p>
  </td></tr>
</table>
</body></html>"""


# ── MAIN ───────────────────────────────────────────────────────────────────────
def main():
    print("=" * 55)
    print(f"  VEKTOR SIGNALS — Daily Run — {DATE_LABEL}")
    print("=" * 55)

    prices      = fetch_prices()
    signals     = generate_signals_claude(prices)
    pdf_paths   = build_pdfs(prices, signals)
    subscribers = fetch_subscribers()
    results     = send_emails(subscribers, pdf_paths, signals)

    print("\n" + "=" * 55)
    print(f"  ✅ COMPLETE — {results['sent']} emails delivered")
    print("=" * 55)


if __name__ == "__main__":
    main()
