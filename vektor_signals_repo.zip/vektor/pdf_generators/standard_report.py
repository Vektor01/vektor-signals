"""
VEKTOR SIGNALS — Standard Daily Report PDF Generator
Covers BTC, ETH, XRP, SOL, BNB — for Standard tier subscribers
"""

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor

BG      = HexColor("#080612")
CARD_BG = HexColor("#0F0C1E")
BORDER  = HexColor("#7B2FBE")
GOLD    = HexColor("#F5C842")
WHITE   = HexColor("#FFFFFF")
MUTED   = HexColor("#6E688A")
MUTED2  = HexColor("#9A94B8")
GREEN   = HexColor("#00C896")
RED     = HexColor("#FF3B3B")
ACCENT  = HexColor("#4DC3FF")
DIVIDER = HexColor("#1E1A35")

BIAS_COLOURS = {
    "STRONG BUY":  HexColor("#00C896"),
    "BUY":         HexColor("#22C55E"),
    "ACCUMULATE":  HexColor("#4DC3FF"),
    "NEUTRAL":     HexColor("#9A94B8"),
    "CAUTION":     HexColor("#FFB800"),
    "REDUCE":      HexColor("#FF6B1A"),
}
RISK_COLOURS = {
    "LOW":         HexColor("#00C896"),
    "MEDIUM":      HexColor("#4DC3FF"),
    "MEDIUM-HIGH": HexColor("#FFB800"),
    "HIGH":        HexColor("#FF6B1A"),
    "VERY HIGH":   HexColor("#FF3B3B"),
}

def rrect(c, x, y, w, h, r, fc=None, sc=None, sw=1):
    if fc: c.setFillColor(fc)
    if sc: c.setStrokeColor(sc); c.setLineWidth(sw)
    else: c.setLineWidth(0)
    c.roundRect(x, y, w, h, r, fill=1 if fc else 0, stroke=1 if sc else 0)

def txt(c, s, x, y, font, size, color, align="left"):
    c.setFont(font, size); c.setFillColor(color)
    if align == "right": c.drawRightString(x, y, s)
    elif align == "center": c.drawCentredString(x, y, s)
    else: c.drawString(x, y, s)

def wrap(c, text, x, y, max_w, font, size, color, lh):
    c.setFont(font, size); c.setFillColor(color)
    words = text.split(); line = ""
    for w2 in words:
        test = line + (" " if line else "") + w2
        if c.stringWidth(test, font, size) <= max_w: line = test
        else:
            if line: c.drawString(x, y, line); y -= lh
            line = w2
    if line: c.drawString(x, y, line); y -= lh
    return y

def build_standard_pdf(output_path, prices, signals, global_data, date_str):
    W, H = A4
    mm = 2.835
    c = canvas.Canvas(output_path, pagesize=A4)

    # Background
    c.setFillColor(BG); c.rect(0, 0, W, H, fill=1, stroke=0)

    # Header
    c.setFillColor(BORDER); c.rect(0, H - 22*mm, 3, 22*mm, fill=1, stroke=0)
    txt(c, "VEKTOR", 8*mm, H - 11*mm, "Helvetica-Bold", 22, GOLD)
    vw = c.stringWidth("VEKTOR", "Helvetica-Bold", 22)
    txt(c, " STANDARD SIGNALS", 8*mm + vw, H - 11*mm, "Helvetica-Bold", 16, WHITE)
    txt(c, "DAILY LARGE CAP REPORT", W - 8*mm, H - 8*mm, "Helvetica-Bold", 7, MUTED2, "right")
    txt(c, date_str + "  |  07:00 GMT", W - 8*mm, H - 14.5*mm, "Helvetica", 6.5, MUTED, "right")
    c.setStrokeColor(BORDER); c.setLineWidth(0.7)
    c.line(8*mm, H - 23*mm, W - 8*mm, H - 23*mm)

    card_w = W - 16*mm
    cy = H - 27*mm
    card_h = 98
    gap = 5

    TICKERS = ["BTC", "ETH", "XRP", "SOL", "BNB"]
    for ticker in TICKERS:
        price_data = prices.get(ticker, {})
        sig = signals.get(ticker, {})
        price = price_data.get("price", 0)
        change = price_data.get("change_24h", 0)
        price_str = f"${price:,.2f}" if price < 1000 else f"${price:,.0f}"
        change_str = f"{change:+.1f}%"
        change_pos = change >= 0

        bias = sig.get("bias", "NEUTRAL")
        risk = sig.get("risk", "MEDIUM")
        bar_col = BIAS_COLOURS.get(bias, BORDER)

        rrect(c, 8*mm, cy - card_h, card_w, card_h, 5, fc=CARD_BG)
        c.setFillColor(bar_col)
        c.roundRect(8*mm, cy - card_h, 3, card_h, 2, fill=1, stroke=0)

        pad = 7*mm
        ix = 8*mm + pad
        iw = card_w - pad - 5*mm

        # Row 1
        r1 = cy - 11
        txt(c, ticker, ix, r1, "Helvetica-Bold", 14, WHITE)
        tw = c.stringWidth(ticker, "Helvetica-Bold", 14)
        txt(c, price_str, 8*mm + card_w - 5*mm, r1, "Helvetica-Bold", 12, WHITE, "right")
        pw = c.stringWidth(price_str, "Helvetica-Bold", 12)
        chg_col = GREEN if change_pos else RED
        txt(c, change_str, 8*mm + card_w - 5*mm - pw - 4, r1, "Helvetica-Bold", 8, chg_col, "right")

        # Bias + risk
        r2 = r1 - 13
        bias_col = BIAS_COLOURS.get(bias, BORDER)
        risk_col  = RISK_COLOURS.get(risk, WHITE)
        bw = c.stringWidth("● " + bias, "Helvetica-Bold", 6.5) + 12
        rrect(c, ix, r2 - 5, bw, 13, 3, fc=bias_col)
        txt(c, "● " + bias, ix + bw/2, r2 - 1, "Helvetica-Bold", 6.5, WHITE, "center")
        rw = c.stringWidth("RISK: " + risk, "Helvetica-Bold", 6.5) + 12
        rrect(c, ix + bw + 5, r2 - 5, rw, 13, 3, fc=HexColor("#1A1630"))
        txt(c, "RISK: " + risk, ix + bw + 5 + rw/2, r2 - 1, "Helvetica-Bold", 6.5, risk_col, "center")

        # Divider
        c.setStrokeColor(DIVIDER); c.setLineWidth(0.4)
        c.line(8*mm + 4*mm, r2 - 8, 8*mm + card_w - 4*mm, r2 - 8)

        # Levels
        r3 = r2 - 20
        levels = [
            ("ENTRY ZONE", sig.get("entry",     "—"), MUTED2),
            ("TARGET 1",   sig.get("target1",   "—"), GREEN),
            ("TARGET 2",   sig.get("target2",   "—"), GREEN),
            ("STOP LOSS",  sig.get("stop_loss", "—"), RED),
        ]
        col_w = iw / 4
        for i, (lbl, val, col) in enumerate(levels):
            cx = ix + i * col_w
            txt(c, lbl, cx, r3, "Helvetica", 5, MUTED)
            txt(c, val, cx, r3 - 10, "Helvetica-Bold", 7, col)

        # Divider
        c.setStrokeColor(DIVIDER); c.setLineWidth(0.3)
        c.line(8*mm + 4*mm, r3 - 18, 8*mm + card_w - 4*mm, r3 - 18)

        # TA + Catalyst
        r4 = r3 - 28
        half = (iw - 4*mm) / 2
        txt(c, "ANALYSIS", ix, r4, "Helvetica-Bold", 5.5, GOLD)
        wrap(c, sig.get("ta_analysis", "Analysis pending."), ix, r4 - 9, half, "Helvetica", 5.8, MUTED2, 8)

        cat_x = ix + half + 4*mm
        txt(c, "CATALYST", cat_x, r4, "Helvetica-Bold", 5.5, ACCENT)
        wrap(c, sig.get("catalyst", "Catalyst pending."), cat_x, r4 - 9, half, "Helvetica", 5.8, MUTED2, 8)

        cy = cy - card_h - gap

    # Footer
    c.setStrokeColor(DIVIDER); c.setLineWidth(0.4)
    c.line(8*mm, 16, W - 8*mm, 16)
    txt(c, "AI market analysis — educational purposes only. Not financial advice. | " + date_str + " | VEKTOR SIGNALS — vektorsignals.com",
        W/2, 9, "Helvetica", 4.8, MUTED, "center")

    c.save()
