"""
VEKTOR SIGNALS — Macro Market Report PDF Generator
One-page market overview: BTC dominance, sector performance, macro conditions
"""

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor

BG      = HexColor("#080612")
CARD_BG = HexColor("#0F0C1E")
BORDER  = HexColor("#7B2FBE")
GOLD    = HexColor("#F5C842")
WHITE   = HexColor("#FFFFFF")
MUTED   = HexColor("#6E688A")
MUTED2  = HexColor("#9A94B8")
GREEN   = HexColor("#00C896")
RED     = HexColor("#FF3B3B")
ORANGE  = HexColor("#FF6B1A")
ACCENT  = HexColor("#4DC3FF")
DIVIDER = HexColor("#1E1A35")

def rrect(c, x, y, w, h, r, fc=None, sc=None, sw=1):
    if fc: c.setFillColor(fc)
    if sc: c.setStrokeColor(sc); c.setLineWidth(sw)
    else: c.setLineWidth(0)
    c.roundRect(x, y, w, h, r, fill=1 if fc else 0, stroke=1 if sc else 0)

def txt(c, s, x, y, font, size, color, align="left"):
    c.setFont(font, size); c.setFillColor(color)
    if align == "right": c.drawRightString(x, y, s)
    elif align == "center": c.drawCentredString(x, y, s)
    else: c.drawString(x, y, s)

def wrap(c, text, x, y, max_w, font, size, color, lh):
    c.setFont(font, size); c.setFillColor(color)
    words = text.split(); line = ""
    for w2 in words:
        test = line + (" " if line else "") + w2
        if c.stringWidth(test, font, size) <= max_w: line = test
        else:
            if line: c.drawString(x, y, line); y -= lh
            line = w2
    if line: c.drawString(x, y, line); y -= lh
    return y

def build_macro_pdf(output_path, prices, global_data, date_str):
    W, H = A4
    mm = 2.835
    c = canvas.Canvas(output_path, pagesize=A4)

    c.setFillColor(BG); c.rect(0, 0, W, H, fill=1, stroke=0)

    # Header
    c.setFillColor(BORDER); c.rect(0, H - 22*mm, 3, 22*mm, fill=1, stroke=0)
    txt(c, "VEKTOR", 8*mm, H - 11*mm, "Helvetica-Bold", 22, GOLD)
    vw = c.stringWidth("VEKTOR", "Helvetica-Bold", 22)
    txt(c, " MACRO REPORT", 8*mm + vw, H - 11*mm, "Helvetica-Bold", 18, WHITE)
    txt(c, "DAILY MARKET OVERVIEW", W - 8*mm, H - 8*mm, "Helvetica-Bold", 7, MUTED2, "right")
    txt(c, date_str + "  |  07:00 GMT", W - 8*mm, H - 14.5*mm, "Helvetica", 6.5, MUTED, "right")
    c.setStrokeColor(BORDER); c.setLineWidth(0.7)
    c.line(8*mm, H - 23*mm, W - 8*mm, H - 23*mm)

    card_w = W - 16*mm

    # ── MACRO CONDITIONS PANEL ──────────────────────────────────────────────────
    mc_y = H - 27*mm
    mc_h = 60
    rrect(c, 8*mm, mc_y - mc_h, card_w, mc_h, 5, fc=CARD_BG)
    c.setFillColor(BORDER); c.roundRect(8*mm, mc_y - mc_h, 3, mc_h, 2, fill=1, stroke=0)

    txt(c, "MACRO CONDITIONS — " + date_str, 8*mm + 7*mm, mc_y - 11, "Helvetica-Bold", 8.5, GOLD)

    btc_dom = global_data.get("btc_dominance", 58.8)
    mcap    = global_data.get("total_mcap", 2.52e12)

    macro_items = [
        ("FED RATE",       "3.50–3.75%",   "HOLD",          MUTED2),
        ("BTC DOMINANCE",  f"{btc_dom}%",  "BITCOIN SEASON" if btc_dom > 50 else "ALT SEASON",
                                                              ACCENT if btc_dom < 50 else ORANGE),
        ("TOTAL MCAP",     f"${mcap/1e12:.2f}T", "",        MUTED2),
        ("FEAR & GREED",   "26",            "FEAR",          RED),
        ("DXY",            "100.4",         "10-MO HIGH ↑",  ORANGE),
        ("WTI CRUDE",      "~$108/bbl",     "HORMUZ RISK",   ORANGE),
        ("ALTCOIN INDEX",  "35/100",        "BTC SEASON",    MUTED2),
    ]

    col_w = card_w / 4
    row = 0
    for i, (label, val, note, col) in enumerate(macro_items):
        col_i = i % 4
        row_i = i // 4
        cx = 8*mm + 7*mm + col_i * col_w
        cy2 = mc_y - 26 - row_i * 22
        txt(c, label, cx, cy2, "Helvetica", 5, MUTED)
        txt(c, val, cx, cy2 - 9, "Helvetica-Bold", 8, col)
        if note:
            txt(c, note, cx, cy2 - 17, "Helvetica", 5.5, MUTED)

    # ── MARKET PRICES TABLE ─────────────────────────────────────────────────────
    pt_y = mc_y - mc_h - 10
    pt_h = 95
    rrect(c, 8*mm, pt_y - pt_h, card_w, pt_h, 5, fc=CARD_BG)
    c.setFillColor(BORDER); c.roundRect(8*mm, pt_y - pt_h, 3, pt_h, 2, fill=1, stroke=0)
    txt(c, "LARGE CAP PRICE SNAPSHOT", 8*mm + 7*mm, pt_y - 12, "Helvetica-Bold", 8.5, GOLD)

    # Table header
    cols = [(0.15, "ASSET"), (0.25, "PRICE"), (0.2, "24H"), (0.2, "7D EST"), (0.2, "OUTLOOK")]
    th_y = pt_y - 24
    c.setStrokeColor(DIVIDER); c.setLineWidth(0.3)
    c.line(8*mm + 5*mm, th_y - 4, 8*mm + card_w - 5*mm, th_y - 4)
    for pct, label in cols:
        cx = 8*mm + 7*mm + pct * 0 
        break
    x_cursor = 8*mm + 7*mm
    for pct, label in cols:
        txt(c, label, x_cursor, th_y, "Helvetica-Bold", 5.5, MUTED)
        x_cursor += pct * card_w

    DISPLAY = ["BTC", "ETH", "XRP", "SOL", "BNB"]
    OUTLOOKS = {
        "BTC": ("ACCUMULATE", ACCENT),
        "ETH": ("ACCUMULATE", ACCENT),
        "XRP": ("ACCUMULATE", ACCENT),
        "SOL": ("ACCUMULATE", ACCENT),
        "BNB": ("BUY", GREEN),
    }
    row_y = th_y - 14
    for ticker in DISPLAY:
        pd = prices.get(ticker, {})
        price = pd.get("price", 0)
        change = pd.get("change_24h", 0)
        price_str  = f"${price:,.2f}" if price < 100 else f"${price:,.0f}"
        change_str = f"{change:+.1f}%"
        chg_col = GREEN if change >= 0 else RED
        outlook, out_col = OUTLOOKS.get(ticker, ("NEUTRAL", MUTED2))

        row_data = [
            (ticker,      WHITE),
            (price_str,   WHITE),
            (change_str,  chg_col),
            ("—",         MUTED),
            (outlook,     out_col),
        ]
        x_cursor = 8*mm + 7*mm
        for j, ((val, col), (pct, _)) in enumerate(zip(row_data, cols)):
            txt(c, val, x_cursor, row_y, "Helvetica-Bold" if j == 0 else "Helvetica", 7.5, col)
            x_cursor += pct * card_w

        c.setStrokeColor(HexColor("#13112A")); c.setLineWidth(0.2)
        c.line(8*mm + 5*mm, row_y - 5, 8*mm + card_w - 5*mm, row_y - 5)
        row_y -= 14

    # ── KEY LEVELS & WATCH ZONES ────────────────────────────────────────────────
    kl_y = pt_y - pt_h - 10
    kl_h = 80
    rrect(c, 8*mm, kl_y - kl_h, card_w, kl_h, 5, fc=CARD_BG)
    c.setFillColor(BORDER); c.roundRect(8*mm, kl_y - kl_h, 3, kl_h, 2, fill=1, stroke=0)
    txt(c, "KEY LEVELS & WATCH ZONES", 8*mm + 7*mm, kl_y - 12, "Helvetica-Bold", 8.5, GOLD)

    zones = [
        ("BTC $68,500", "MAJOR LIQUIDATION CLUSTER — Binance heatmap. Loss of this triggers cascade to $64,800.", RED),
        ("BTC $72,000", "CRITICAL RECOVERY LEVEL — Reclaim this and SOL/ETH follow to resistance.", GREEN),
        ("ETH $2,000",  "INSTITUTIONAL FLOOR — BlackRock ETHB buyers defending this level. Break = pain.", ORANGE),
        ("XRP $2.00",   "PIVOT LEVEL — Repeated seller exhaustion signals. Break below = $1.62 Fib.", ORANGE),
        ("SOL $80.00",  "PSYCHOLOGICAL SUPPORT — Firedancer narrative keeps buyers here.", ACCENT),
    ]
    zy = kl_y - 26
    for level, desc, col in zones:
        lw = c.stringWidth(level, "Helvetica-Bold", 7) + 10
        rrect(c, 8*mm + 7*mm, zy - 6, lw, 12, 2, fc=HexColor("#1A1630"))
        txt(c, level, 8*mm + 7*mm + lw/2, zy - 1, "Helvetica-Bold", 7, col, "center")
        wrap(c, desc, 8*mm + 7*mm + lw + 6, zy, card_w - lw - 24*mm, "Helvetica", 6, MUTED2, 8)
        zy -= 14

    # ── VEKTOR WEEKLY THESIS ────────────────────────────────────────────────────
    th_y2 = kl_y - kl_h - 10
    th_h  = 70
    rrect(c, 8*mm, th_y2 - th_h, card_w, th_h, 5, fc=HexColor("#0D0A1E"), sc=BORDER, sw=0.5)
    txt(c, "VEKTOR WEEKLY THESIS", 8*mm + 7*mm, th_y2 - 12, "Helvetica-Bold", 8.5, GOLD)
    c.setStrokeColor(DIVIDER); c.setLineWidth(0.3)
    c.line(8*mm + 5*mm, th_y2 - 17, 8*mm + card_w - 5*mm, th_y2 - 17)

    thesis = [
        ("MACRO", "Post-FOMC sell-off is in the price. Hawkish hold delivered sell-the-news as expected (8 of 9 meetings). The next move is determined by: (1) ETF inflows this week, (2) BTC holding $68.5K, (3) FTX $2.2B payout reinvestment flow on Mar 31."),
        ("STRUCTURE", "BTC dominance at 58.8% in Bitcoin Season. Altcoin Season Index 35/100. This is NOT an alt chase market — it is a selective accumulation window for fundamentally strong assets at discounted levels."),
        ("OPPORTUNITY", "The SEC/CFTC commodity classification of Mar 17 is the most underpriced event in the market. 16 tokens got commodity status. Institutional flows that were blocked are now unlocked. This hasn't priced in yet."),
        ("POSITIONING", "Keep 20-30% dry powder. Scale into BTC/ETH/SOL accumulation zones across 2-3 entries. HYPE showing relative strength — watch for decoupling. Do not chase — let price come to you."),
    ]
    ty = th_y2 - 28
    for label, body in thesis:
        txt(c, label + ":", 8*mm + 7*mm, ty, "Helvetica-Bold", 6, ACCENT)
        lw2 = c.stringWidth(label + ": ", "Helvetica-Bold", 6)
        ty = wrap(c, body, 8*mm + 7*mm + lw2, ty, card_w - 14*mm - lw2, "Helvetica", 6, MUTED2, 8)
        ty -= 4

    # Footer
    c.setStrokeColor(DIVIDER); c.setLineWidth(0.4)
    c.line(8*mm, 16, W - 8*mm, 16)
    txt(c, "AI market analysis — educational purposes only. Not financial advice. | " + date_str + " | VEKTOR SIGNALS — vektorsignals.com",
        W/2, 9, "Helvetica", 4.8, MUTED, "center")
    c.save()
