const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// ── MAP YOUR STRIPE PRICE IDs TO TIERS ────────────────────────
// Replace these with your real Price IDs from Stripe Dashboard
const PRICE_TO_TIER = {
  'price_REPLACE_STANDARD_MONTHLY': 'standard',
  'price_REPLACE_STANDARD_ANNUAL':  'standard',
  'price_REPLACE_VIP_MONTHLY':      'vip',
  'price_REPLACE_VIP_ANNUAL':       'vip',
};

exports.handler = async (event) => {
  const sig = event.headers['stripe-signature'];
  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  const { type, data } = stripeEvent;
  console.log(`Stripe event received: ${type}`);

  // ── CHECKOUT COMPLETED → Activate subscriber ─────────────────
  if (type === 'checkout.session.completed') {
    const session    = data.object;
    const email      = session.customer_details?.email;
    const customerId = session.customer;
    const subId      = session.subscription;

    // Get price ID from subscription to determine tier
    let tier = 'standard';
    if (subId) {
      try {
        const sub    = await stripe.subscriptions.retrieve(subId);
        const priceId = sub.items.data[0]?.price?.id;
        tier = PRICE_TO_TIER[priceId] || 'standard';
      } catch (e) {
        console.error('Could not retrieve subscription:', e.message);
      }
    }

    if (email) {
      const { error } = await supabase
        .from('subscribers')
        .upsert({
          email,
          tier,
          active: true,
          stripe_customer_id: customerId,
          stripe_sub_id: subId,
          cancelled_at: null,
        }, { onConflict: 'email' });

      if (error) {
        console.error('Supabase error activating subscriber:', error);
      } else {
        console.log(`✅ Activated ${tier} subscriber: ${email}`);
      }
    }
  }

  // ── SUBSCRIPTION CANCELLED → Deactivate ──────────────────────
  if (type === 'customer.subscription.deleted') {
    const sub = data.object;
    const { error } = await supabase
      .from('subscribers')
      .update({
        active: false,
        cancelled_at: new Date().toISOString()
      })
      .eq('stripe_sub_id', sub.id);

    if (error) {
      console.error('Error deactivating subscriber:', error);
    } else {
      console.log(`❌ Deactivated subscription: ${sub.id}`);
    }
  }

  // ── PAYMENT FAILED → Deactivate access ───────────────────────
  if (type === 'invoice.payment_failed') {
    const invoice    = data.object;
    const customerId = invoice.customer;
    const { error }  = await supabase
      .from('subscribers')
      .update({ active: false })
      .eq('stripe_customer_id', customerId);

    if (error) {
      console.error('Error on payment failure update:', error);
    } else {
      console.log(`⚠️ Access suspended — payment failed for: ${customerId}`);
    }
  }

  // ── SUBSCRIPTION REACTIVATED ──────────────────────────────────
  if (type === 'customer.subscription.updated') {
    const sub = data.object;
    if (sub.status === 'active') {
      const { error } = await supabase
        .from('subscribers')
        .update({ active: true, cancelled_at: null })
        .eq('stripe_sub_id', sub.id);

      if (!error) console.log(`✅ Reactivated subscription: ${sub.id}`);
    }
  }

  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};
