-- ================================================================
-- VEKTOR SIGNALS — Supabase Schema
-- Run this entire file in your Supabase SQL Editor (one time setup)
-- ================================================================

-- SUBSCRIBERS TABLE
create table if not exists subscribers (
  id              uuid primary key default gen_random_uuid(),
  email           text unique not null,
  tier            text not null default 'free'
                    check (tier in ('free', 'standard', 'vip')),
  active          boolean not null default true,
  stripe_customer_id  text unique,
  stripe_sub_id       text unique,
  subscribed_at   timestamptz default now(),
  cancelled_at    timestamptz,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- SIGNAL LOGS TABLE (stores every generated signal for your records)
create table if not exists signal_logs (
  id          uuid primary key default gen_random_uuid(),
  run_date    date not null default current_date,
  tier        text not null,
  asset       text not null,
  bias        text,
  entry_zone  text,
  target_1    text,
  target_2    text,
  stop_loss   text,
  price_at_signal numeric,
  raw_json    jsonb,
  created_at  timestamptz default now()
);

-- EMAIL DELIVERY LOG
create table if not exists email_log (
  id            uuid primary key default gen_random_uuid(),
  sent_at       timestamptz default now(),
  recipient     text not null,
  tier          text not null,
  status        text not null default 'sent',
  resend_id     text,
  error_msg     text
);

-- INDEXES
create index if not exists idx_subscribers_active on subscribers(active, tier);
create index if not exists idx_signal_logs_date on signal_logs(run_date);
create index if not exists idx_email_log_sent on email_log(sent_at);

-- ROW LEVEL SECURITY (keeps data safe)
alter table subscribers   enable row level security;
alter table signal_logs   enable row level security;
alter table email_log     enable row level security;

-- Service role has full access (used by automation)
create policy "service_role_all" on subscribers   for all using (true);
create policy "service_role_all" on signal_logs   for all using (true);
create policy "service_role_all" on email_log     for all using (true);

-- HELPER: Auto-update updated_at timestamp
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger subscribers_updated_at
  before update on subscribers
  for each row execute function update_updated_at();

-- ================================================================
-- TEST: Insert a test subscriber to confirm setup
-- ================================================================
-- insert into subscribers (email, tier) values ('your@email.com', 'vip');
-- select * from subscribers;
