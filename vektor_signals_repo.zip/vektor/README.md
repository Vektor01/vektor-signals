# VEKTOR SIGNALS — Automation Engine

Fully automated daily crypto signal delivery system.
Runs every weekday at 6:30am GMT. Zero manual input required after setup.

## Architecture

```
GitHub Actions (cron 6:30am)
    │
    ├── CoinGecko API → live prices
    ├── Claude API → AI signal analysis
    ├── ReportLab → 4x PDF reports
    └── Resend → email to Supabase subscribers
              │
              └── Stripe Webhook → manages subscriptions
```

## Reports Generated Daily

| Report | Tier | Assets |
|--------|------|--------|
| VIP Large Cap | VIP + All Access | BTC, ETH, XRP, SOL, BNB, HYPE |
| Wild Card | Wild Card + All Access | 5 speculative picks |
| Standard Signals | Standard + All Access | BTC, ETH, XRP, SOL, BNB |
| Macro Report | Standard + VIP + All Access | Market overview |

## Setup — One Time (30 mins)

### 1. Clone & configure
```bash
git clone https://github.com/YOUR_USERNAME/vektor-signals.git
cd vektor-signals
cp .env.example .env
# Fill in your API keys in .env
```

### 2. Add GitHub Secrets
Go to: Repo → Settings → Secrets → Actions → New repository secret

Add each key from .env.example:
- `COINGECKO_API_KEY`
- `ANTHROPIC_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_KEY`
- `RESEND_API_KEY`
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`

### 3. Set up Supabase
1. Go to Supabase → SQL Editor
2. Paste contents of `scripts/supabase_schema.sql`
3. Click Run

### 4. Set up Resend
1. Sign up at resend.com
2. Add your domain (vektorsignals.com)
3. Verify DNS records
4. Copy API key → add to secrets

### 5. Set up Stripe Webhook
1. Stripe Dashboard → Webhooks → Add endpoint
2. URL: `https://vektorsignals.com/.netlify/functions/stripe-webhook`
3. Events: `checkout.session.completed`, `customer.subscription.deleted`
4. Copy signing secret → `STRIPE_WEBHOOK_SECRET`

### 6. Test the engine
```bash
# Trigger manually via GitHub Actions
# Actions → Daily Signal Engine → Run workflow
```

## Subscription Tiers

| Tier | Monthly Price | Reports |
|------|--------------|---------|
| Standard | £X/mo | Standard + Macro |
| Wild Card | £X/mo | Wild Card only |
| VIP | £X/mo | VIP + Standard + Macro |
| All Access | £X/mo | All 4 reports |

## Support
Built by Vektor Signals. vektorsignals.com
