from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white, black
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
import textwrap

# ── BRAND COLOURS ──────────────────────────────────────────────────────────────
BG          = HexColor("#0B0818")
CARD_BG     = HexColor("#130F24")
BORDER      = HexColor("#7B2FBE")
GOLD        = HexColor("#F5C842")
WHITE       = HexColor("#FFFFFF")
MUTED       = HexColor("#8A84A3")
LABEL_BG    = HexColor("#1E1635")
WARN_BG     = HexColor("#1A0F2E")
WARN_BORDER = HexColor("#F5C842")

RISK_EXTREME    = HexColor("#FF3B3B")
RISK_VERY_HIGH  = HexColor("#FF6B1A")
RISK_HIGH       = HexColor("#FFB800")
RISK_MED_HIGH   = HexColor("#4DC3FF")

TYPE_DEGEN      = HexColor("#FF3B3B")
TYPE_MOMENTUM   = HexColor("#7B2FBE")
TYPE_NARRATIVE  = HexColor("#1A6FFF")
TYPE_ACCUM      = HexColor("#00C896")
TYPE_VALUE      = HexColor("#22C55E")

RISK_COLOURS = {
    "EXTREME":     RISK_EXTREME,
    "VERY HIGH":   RISK_VERY_HIGH,
    "HIGH":        RISK_HIGH,
    "MEDIUM-HIGH": RISK_MED_HIGH,
}
TYPE_COLOURS = {
    "DEGEN LONG":     TYPE_DEGEN,
    "MOMENTUM LONG":  TYPE_MOMENTUM,
    "NARRATIVE LONG": TYPE_NARRATIVE,
    "ACCUMULATION":   TYPE_ACCUM,
    "VALUE LONG":     TYPE_VALUE,
}

# ── SIGNAL DATA ────────────────────────────────────────────────────────────────
SIGNALS = [
    {
        "num": "01", "pair": "QNT / USDT", "price": "$110.40", "change": "+7.5%",
        "type": "MOMENTUM LONG", "risk": "HIGH",
        "entry": "$105.00–$112.00", "t1": "$130.00 (+18%)", "t2": "$155.00 (+40%)", "sl": "$95.00 (-14%)",
        "why": "QNT just received a spot listing on Robinhood — one of the cleanest short-term catalysts in crypto. New retail access + instant volume spike = textbook momentum entry. Quant's core product (Overledger) has real enterprise adoption. This isn't a meme.",
        "catalyst": "Robinhood spot listing live today. Fresh retail access driving immediate volume surge. Enterprise interoperability narrative still underpriced vs peers.",
    },
    {
        "num": "02", "pair": "FET / USDT", "price": "$1.38", "change": "+6.5%",
        "type": "MOMENTUM LONG", "risk": "HIGH",
        "entry": "$1.28–$1.40", "t1": "$1.72 (+25%)", "t2": "$2.10 (+52%)", "sl": "$1.12 (-19%)",
        "why": "FET is leading the AI token sector with consistent gains. The AI-crypto convergence narrative is one of the only working themes in this market right now. Fetch.ai has real infrastructure — not just a ticker. Volume confirms genuine buying.",
        "catalyst": "AI token sector rotation in play. SEC/CFTC commodity classification on March 17 provides structural tailwind. Autonomous agent economy narrative accelerating in 2026.",
    },
    {
        "num": "03", "pair": "SUI / USDT", "price": "$2.18", "change": "+3.2%",
        "type": "ACCUMULATION", "risk": "MEDIUM-HIGH",
        "entry": "$2.05–$2.20", "t1": "$2.75 (+26%)", "t2": "$4.00 (+83%)", "sl": "$1.82 (-17%)",
        "why": "SUI is approaching a critical technical zone after weeks of consolidation. Institutional momentum is building — Nasdaq tokenised equities are deploying on Sui. This is the highest-quality L1 setup in the current market. Accumulate, not chase.",
        "catalyst": "Nasdaq tokenised equities on Sui = real institutional pipeline. Break above $2.20–$2.75 resistance targets $4+ expansion. USDsui stablecoin now live, expanding ecosystem utility.",
    },
    {
        "num": "04", "pair": "ZEC / USDT", "price": "$58.20", "change": "+4.1%",
        "type": "NARRATIVE LONG", "risk": "VERY HIGH",
        "entry": "$54.00–$60.00", "t1": "$78.00 (+34%)", "t2": "$110.00 (+90%)", "sl": "$46.00 (-21%)",
        "why": "Privacy coins are having a moment. ZEC has broken out sharply on renewed interest in financial privacy as surveillance concerns grow. The SEC/CFTC commodity classification creates a cleaner legal standing for Zcash. Contrarian narrative with real legs.",
        "catalyst": "Privacy sector breakout in full effect. Financial surveillance narrative intensifying globally. Commodity classification boosts institutional comfort. XMR resurgence lifting whole sector.",
    },
    {
        "num": "05", "pair": "DOGE / USDT", "price": "$0.0943", "change": "+2.8%",
        "type": "DEGEN LONG", "risk": "EXTREME",
        "entry": "$0.088–$0.098", "t1": "$0.130 (+38%)", "t2": "$0.180 (+91%)", "sl": "$0.076 (-19%)",
        "why": "DOGE is the highest-beta meme play with an actual utility narrative — X Payments integration is real and growing. MACD histogram has turned positive. If BTC stabilises above $70K and risk sentiment shifts, DOGE moves first and hardest. MAX 0.5% portfolio.",
        "catalyst": "X Payments mainstream integration accelerating. Meme coin ETF optimism. MACD histogram bullish crossover confirmed. Altcoin Season index recovering from lows — DOGE leads when the tide turns.",
    },
]

# ── HELPERS ───────────────────────────────────────────────────────────────────
def draw_rounded_rect(c, x, y, w, h, r, fill_color=None, stroke_color=None, stroke_width=1):
    if fill_color:
        c.setFillColor(fill_color)
    if stroke_color:
        c.setStrokeColor(stroke_color)
        c.setLineWidth(stroke_width)
    else:
        c.setLineWidth(0)
    c.roundRect(x, y, w, h, r, fill=1 if fill_color else 0, stroke=1 if stroke_color else 0)

def draw_text(c, text, x, y, font, size, color, align="left"):
    c.setFont(font, size)
    c.setFillColor(color)
    if align == "right":
        c.drawRightString(x, y, text)
    elif align == "center":
        c.drawCentredString(x, y, text)
    else:
        c.drawString(x, y, text)

def wrap_text_lines(c, text, x, y, max_width, font, size, color, line_height):
    c.setFont(font, size)
    c.setFillColor(color)
    words = text.split()
    lines = []
    current = ""
    for word in words:
        test = current + (" " if current else "") + word
        if c.stringWidth(test, font, size) <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    for line in lines:
        c.drawString(x, y, line)
        y -= line_height
    return y

def draw_badge(c, text, cx, cy, bg_color, text_color=WHITE, font="Helvetica-Bold", size=6.5):
    w = c.stringWidth(text, font, size) + 10
    h = 13
    draw_rounded_rect(c, cx - w/2, cy - h/2, w, h, 3, fill_color=bg_color)
    draw_text(c, text, cx, cy - 4, font, size, text_color, "center")

# ── MAIN BUILD ────────────────────────────────────────────────────────────────
def build_pdf(output_path):
    W, H = A4  # 595 x 842
    c = canvas.Canvas(output_path, pagesize=A4)

    # Background
    c.setFillColor(BG)
    c.rect(0, 0, W, H, fill=1, stroke=0)

    # ── HEADER ──
    hdr_y = H - 42*mm
    draw_text(c, "VEKTOR", 14*mm, hdr_y, "Helvetica-Bold", 26, GOLD)
    vek_w = c.stringWidth("VEKTOR", "Helvetica-Bold", 26)
    draw_text(c, " WILD CARD", 14*mm + vek_w, hdr_y, "Helvetica-Bold", 26, WHITE)

    # Right header block
    draw_text(c, "SPECULATIVE SIGNALS — FINAL WEEK MARCH EDITION", W - 14*mm, hdr_y + 6, "Helvetica", 6.5, MUTED, "right")
    draw_text(c, "Tuesday 24 March 2026  |  07:00 GMT  |  MAX 1% PORTFOLIO PER TRADE", W - 14*mm, hdr_y - 2, "Helvetica", 6.5, MUTED, "right")

    # Divider
    c.setStrokeColor(BORDER)
    c.setLineWidth(0.6)
    c.line(14*mm, hdr_y - 7, W - 14*mm, hdr_y - 7)

    # ── WARNING BANNER ──
    warn_y = hdr_y - 22
    warn_h = 26
    draw_rounded_rect(c, 14*mm, warn_y - warn_h, W - 28*mm, warn_h, 3,
                      fill_color=WARN_BG, stroke_color=WARN_BORDER, stroke_width=0.8)
    c.setFont("Helvetica-Bold", 6.5)
    c.setFillColor(GOLD)
    c.drawString(18*mm, warn_y - 10, "MACRO NOTE:")
    c.setFont("Helvetica", 6.5)
    c.setFillColor(WHITE)
    warn_text = ("FOMC sell-off already priced in from March 18. SEC/CFTC joint commodity classification "
                 "(March 17) has NOT fully priced in — structural tailwind building. "
                 "Wild Card positions MAX 0.5% portfolio. These coins can move 30–60% on a single catalyst. "
                 "Selective, narrative-driven market — size accordingly.")
    wrap_text_lines(c, warn_text, 55*mm, warn_y - 10, W - 28*mm - 44*mm, "Helvetica", 6.5, WHITE, 9)

    # ── SIGNAL CARDS ──
    card_x = 14*mm
    card_w = W - 28*mm
    card_h = 92
    gap = 6
    start_y = warn_y - warn_h - 10

    for sig in SIGNALS:
        y_top = start_y
        y_bot = y_top - card_h

        # Card background
        draw_rounded_rect(c, card_x, y_bot, card_w, card_h, 4, fill_color=CARD_BG)
        # Left accent bar
        c.setFillColor(BORDER)
        c.roundRect(card_x, y_bot, 3, card_h, 2, fill=1, stroke=0)

        # Wild number
        draw_text(c, f"WILD #{sig['num']}", card_x + 8*mm, y_top - 13, "Helvetica", 7, MUTED)

        # Pair name
        draw_text(c, sig["pair"], card_x + 8*mm, y_top - 24, "Helvetica-Bold", 13, WHITE)
        pair_w = c.stringWidth(sig["pair"], "Helvetica-Bold", 13)

        # Price
        draw_text(c, sig["price"], card_x + 8*mm + pair_w + 6, y_top - 24, "Helvetica-Bold", 11, WHITE)
        price_w = c.stringWidth(sig["price"], "Helvetica-Bold", 11)

        # Change
        draw_text(c, sig["change"], card_x + 8*mm + pair_w + 6 + price_w + 4, y_top - 24,
                  "Helvetica-Bold", 9, RISK_COLOURS.get("HIGH"))

        # Signal type badge
        type_col = TYPE_COLOURS.get(sig["type"], BORDER)
        badge_x = card_x + card_w - 60*mm
        badge_y = y_top - 19
        draw_badge(c, "▲ " + sig["type"], badge_x, badge_y, type_col)

        # Risk label
        risk_col = RISK_COLOURS.get(sig["risk"], WHITE)
        draw_text(c, "RISK: " + sig["risk"], card_x + card_w - 14*mm, y_top - 24,
                  "Helvetica-Bold", 7.5, risk_col, "right")

        # ── Levels row ──
        lvl_y = y_top - 36
        cols = [
            ("ENTRY ZONE", sig["entry"]),
            ("TARGET 1", sig["t1"]),
            ("TARGET 2", sig["t2"]),
            ("STOP LOSS", sig["sl"]),
        ]
        col_w = (card_w - 16*mm) / 4
        for i, (label, val) in enumerate(cols):
            cx = card_x + 8*mm + i * col_w
            draw_text(c, label, cx, lvl_y, "Helvetica", 5.5, MUTED)
            # colour T1/T2 green, SL red
            val_col = WHITE
            if "TARGET" in label:
                val_col = HexColor("#00C896")
            elif "STOP" in label:
                val_col = RISK_EXTREME
            draw_text(c, val, cx, lvl_y - 10, "Helvetica-Bold", 7.5, val_col)

        # Divider line
        div_y = lvl_y - 20
        c.setStrokeColor(HexColor("#2A2240"))
        c.setLineWidth(0.4)
        c.line(card_x + 6*mm, div_y, card_x + card_w - 6*mm, div_y)

        # WHY text
        why_y = div_y - 8
        c.setFont("Helvetica-Bold", 6)
        c.setFillColor(GOLD)
        c.drawString(card_x + 8*mm, why_y, "WHY //")
        why_label_w = c.stringWidth("WHY // ", "Helvetica-Bold", 6)
        why_y = wrap_text_lines(c, sig["why"],
                                card_x + 8*mm + why_label_w, why_y,
                                (card_w / 2) - 16*mm - why_label_w,
                                "Helvetica", 6, WHITE, 8)

        # CATALYST text (right column)
        cat_x = card_x + card_w / 2 + 2*mm
        cat_y = div_y - 8
        c.setFont("Helvetica-Bold", 6)
        c.setFillColor(HexColor("#4DC3FF"))
        c.drawString(cat_x, cat_y, "CATALYST //")
        cat_label_w = c.stringWidth("CATALYST // ", "Helvetica-Bold", 6)
        wrap_text_lines(c, sig["catalyst"],
                        cat_x + cat_label_w, cat_y,
                        (card_w / 2) - 16*mm - cat_label_w,
                        "Helvetica", 6, MUTED, 8)

        start_y = y_bot - gap

    # ── FOOTER ──
    c.setStrokeColor(HexColor("#2A2240"))
    c.setLineWidth(0.4)
    c.line(14*mm, 18, W - 14*mm, 18)
    draw_text(c, "AI market analysis — educational purposes only. Not financial advice. Prices: CoinGecko/CMC | 24 Mar 2026 — 07:00 GMT",
              W / 2, 11, "Helvetica", 5.5, MUTED, "center")
    draw_text(c, "VEKTOR SIGNALS — vektorsignals.com", W / 2, 5, "Helvetica-Bold", 5.5, BORDER, "center")

    c.save()
    print("PDF saved.")

build_pdf("/mnt/user-data/outputs/vektor_wildcard_march24.pdf")
