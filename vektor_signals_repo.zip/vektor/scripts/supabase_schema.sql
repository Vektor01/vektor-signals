-- ============================================================
-- VEKTOR SIGNALS — Supabase Database Schema
-- Run this in your Supabase SQL editor
-- ============================================================

-- Subscribers table
CREATE TABLE IF NOT EXISTS subscribers (
  id                  UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email               TEXT UNIQUE NOT NULL,
  tier                TEXT NOT NULL DEFAULT 'standard',
    -- tiers: 'standard' | 'vip' | 'wildcard' | 'all_access'
  active              BOOLEAN DEFAULT TRUE,
  stripe_customer_id  TEXT,
  stripe_sub_id       TEXT,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_subscribers_active ON subscribers(active);
CREATE INDEX IF NOT EXISTS idx_subscribers_tier   ON subscribers(tier);
CREATE INDEX IF NOT EXISTS idx_subscribers_stripe ON subscribers(stripe_customer_id);

-- Auto-update timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER subscribers_updated_at
  BEFORE UPDATE ON subscribers
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Signal delivery log (optional but useful)
CREATE TABLE IF NOT EXISTS delivery_log (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  date         DATE NOT NULL,
  report_type  TEXT NOT NULL,
  emails_sent  INTEGER DEFAULT 0,
  status       TEXT DEFAULT 'pending',
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Row Level Security (keep subscriber data private)
ALTER TABLE subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_log ENABLE ROW LEVEL SECURITY;

-- Only service role (your backend) can read/write
CREATE POLICY "Service only" ON subscribers
  USING (auth.role() = 'service_role');

CREATE POLICY "Service only" ON delivery_log
  USING (auth.role() = 'service_role');

-- ============================================================
-- TEST: Insert a manual subscriber (remove before production)
-- ============================================================
-- INSERT INTO subscribers (email, tier, active)
-- VALUES ('yourname@email.com', 'vip', TRUE);

-- ============================================================
-- VERIFY: Check your table
-- ============================================================
-- SELECT * FROM subscribers;
