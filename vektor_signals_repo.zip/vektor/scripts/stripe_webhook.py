"""
VEKTOR SIGNALS — Stripe Webhook Handler
Deploy this as a Netlify Function or standalone server.
Handles: checkout.session.completed, customer.subscription.deleted
"""

import json
import os
import stripe
from supabase import create_client

STRIPE_SECRET       = os.environ["STRIPE_SECRET_KEY"]
STRIPE_WEBHOOK_SEC  = os.environ["STRIPE_WEBHOOK_SECRET"]
SUPABASE_URL        = os.environ["SUPABASE_URL"]
SUPABASE_KEY        = os.environ["SUPABASE_KEY"]

stripe.api_key = STRIPE_SECRET

# Map your Stripe Price IDs to tier names
# Update these with your actual Stripe price IDs
PRICE_TO_TIER = {
    "price_STANDARD_MONTHLY":  "standard",
    "price_VIP_MONTHLY":       "vip",
    "price_WILDCARD_MONTHLY":  "wildcard",
    "price_ALL_ACCESS_MONTHLY": "all_access",
}

def handler(event, context):
    """Netlify Function handler."""
    payload   = event["body"]
    sig_header = event["headers"].get("stripe-signature", "")

    try:
        stripe_event = stripe.Webhook.construct_event(
            payload, sig_header, STRIPE_WEBHOOK_SEC
        )
    except (ValueError, stripe.error.SignatureVerificationError) as e:
        return {"statusCode": 400, "body": str(e)}

    sb = create_client(SUPABASE_URL, SUPABASE_KEY)

    # ── New subscriber ──────────────────────────────────────────────────────────
    if stripe_event["type"] == "checkout.session.completed":
        session = stripe_event["data"]["object"]
        email     = session["customer_details"]["email"]
        customer  = session["customer"]
        sub_id    = session.get("subscription")

        # Get the price/tier from the subscription
        tier = "standard"  # default
        if sub_id:
            sub = stripe.Subscription.retrieve(sub_id)
            price_id = sub["items"]["data"][0]["price"]["id"]
            tier = PRICE_TO_TIER.get(price_id, "standard")

        # Upsert into Supabase
        sb.table("subscribers").upsert({
            "email":              email,
            "tier":               tier,
            "active":             True,
            "stripe_customer_id": customer,
            "stripe_sub_id":      sub_id,
        }).execute()

        print(f"✓ New subscriber: {email} ({tier})")

    # ── Cancelled subscription ──────────────────────────────────────────────────
    elif stripe_event["type"] == "customer.subscription.deleted":
        sub    = stripe_event["data"]["object"]
        cust_id = sub["customer"]

        sb.table("subscribers").update({"active": False}).eq(
            "stripe_customer_id", cust_id
        ).execute()

        print(f"✓ Cancelled: customer {cust_id}")

    # ── Payment failed (optional: send warning email) ───────────────────────────
    elif stripe_event["type"] == "invoice.payment_failed":
        invoice = stripe_event["data"]["object"]
        email   = invoice.get("customer_email", "")
        print(f"⚠ Payment failed: {email}")
        # TODO: send payment retry email via Resend

    return {"statusCode": 200, "body": json.dumps({"received": True})}
