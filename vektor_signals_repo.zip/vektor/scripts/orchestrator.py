"""
VEKTOR SIGNALS — Daily Orchestrator
Runs every weekday morning at 6:30 GMT via GitHub Actions.
Flow: Fetch Prices → Generate Signal Copy (Claude AI) → Build PDFs → Email Subscribers
"""

import os
import json
import requests
import anthropic
from datetime import datetime
from supabase import create_client
import resend
from pdf_generators.vip_report import build_vip_pdf
from pdf_generators.wildcard_report import build_wildcard_pdf
from pdf_generators.standard_report import build_standard_pdf
from pdf_generators.macro_report import build_macro_pdf

# ── CONFIG ─────────────────────────────────────────────────────────────────────
COINGECKO_KEY   = os.environ["COINGECKO_API_KEY"]
ANTHROPIC_KEY   = os.environ["ANTHROPIC_API_KEY"]
SUPABASE_URL    = os.environ["SUPABASE_URL"]
SUPABASE_KEY    = os.environ["SUPABASE_KEY"]
RESEND_KEY      = os.environ["RESEND_API_KEY"]
OUTPUT_DIR      = "outputs"
FROM_EMAIL      = "signals@vektorsignals.com"
TODAY           = datetime.utcnow().strftime("%A %d %B %Y")
DATE_SLUG       = datetime.utcnow().strftime("%Y%m%d")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── COIN IDs ────────────────────────────────────────────────────────────────────
VIP_COINS = {
    "BTC":  "bitcoin",
    "ETH":  "ethereum",
    "XRP":  "ripple",
    "SOL":  "solana",
    "BNB":  "binancecoin",
    "HYPE": "hyperliquid",
}

WILDCARD_COINS = {
    "QNT":   "quant-network",
    "FET":   "fetch-ai",
    "SUI":   "sui",
    "ZEC":   "zcash",
    "DOGE":  "dogecoin",
}

STANDARD_COINS = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "SOL": "solana",
    "XRP": "ripple",
    "BNB": "binancecoin",
}

# ── STEP 1: FETCH PRICES ────────────────────────────────────────────────────────
def fetch_prices(coin_map: dict) -> dict:
    """Pull current prices, 24h change, market cap from CoinGecko."""
    ids = ",".join(coin_map.values())
    url = "https://api.coingecko.com/api/v3/simple/price"
    params = {
        "ids": ids,
        "vs_currencies": "usd",
        "include_24hr_change": "true",
        "include_market_cap": "true",
        "x_cg_demo_api_key": COINGECKO_KEY,
    }
    resp = requests.get(url, params=params, timeout=15)
    resp.raise_for_status()
    raw = resp.json()

    # Remap to ticker keys
    prices = {}
    for ticker, cg_id in coin_map.items():
        data = raw.get(cg_id, {})
        prices[ticker] = {
            "price":      data.get("usd", 0),
            "change_24h": data.get("usd_24h_change", 0),
            "mcap":       data.get("usd_market_cap", 0),
        }
    return prices

# ── STEP 2: FETCH GLOBAL MARKET DATA ───────────────────────────────────────────
def fetch_global_data() -> dict:
    """Pull BTC dominance, total market cap, fear & greed proxy."""
    url = "https://api.coingecko.com/api/v3/global"
    resp = requests.get(url, params={"x_cg_demo_api_key": COINGECKO_KEY}, timeout=10)
    resp.raise_for_status()
    data = resp.json().get("data", {})
    return {
        "btc_dominance": round(data.get("market_cap_percentage", {}).get("btc", 0), 1),
        "total_mcap":    data.get("total_market_cap", {}).get("usd", 0),
        "volume_24h":    data.get("total_volume", {}).get("usd", 0),
    }

# ── STEP 3: GENERATE SIGNAL COPY VIA CLAUDE ────────────────────────────────────
def generate_signals_ai(report_type: str, prices: dict, global_data: dict) -> dict:
    """
    Call Claude API to generate fresh signal copy for each coin.
    Returns structured JSON with analysis for each ticker.
    """
    client = anthropic.Anthropic(api_key=ANTHROPIC_KEY)

    price_block = "\n".join([
        f"- {ticker}: ${data['price']:,.4f}  ({data['change_24h']:+.2f}% 24h)"
        for ticker, data in prices.items()
    ])

    system_prompt = """You are Vektor Signals, an elite crypto trading analysis service.
Generate precise, actionable trading signal analysis. 
Always respond with ONLY valid JSON, no markdown, no preamble.
Be concise, specific, and use professional trading terminology.
Base all analysis on current price action and market conditions."""

    user_prompt = f"""Generate daily {report_type} trading signals for today {TODAY}.

LIVE MARKET DATA:
{price_block}

GLOBAL: BTC Dominance {global_data['btc_dominance']}% | Total MCap ${global_data['total_mcap']/1e12:.2f}T

For each ticker, return a JSON object with this exact structure:
{{
  "TICKER": {{
    "bias": "STRONG BUY | BUY | ACCUMULATE | NEUTRAL | CAUTION | REDUCE",
    "risk": "LOW | MEDIUM | MEDIUM-HIGH | HIGH | VERY HIGH",
    "entry": "price range e.g. $X,XXX - $X,XXX",
    "target1": "$X,XXX (+XX%)",
    "target2": "$X,XXX (+XX%)",
    "stop_loss": "$X,XXX (-XX%)",
    "rsi_estimate": "XX (OVERSOLD/NEUTRAL/OVERBOUGHT)",
    "structure": "3-4 word market structure label",
    "ta_analysis": "2-3 sentence technical analysis",
    "catalyst": "2-3 sentence catalyst and thesis"
  }}
}}

Return ONLY the JSON object. No other text."""

    msg = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=2000,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )

    raw = msg.content[0].text.strip()
    return json.loads(raw)

# ── STEP 4: BUILD ALL PDFs ──────────────────────────────────────────────────────
def build_all_pdfs(vip_prices, wildcard_prices, standard_prices,
                   vip_signals, wildcard_signals, standard_signals,
                   global_data, today_str):
    paths = {}

    paths["vip"] = f"{OUTPUT_DIR}/vektor_vip_{DATE_SLUG}.pdf"
    build_vip_pdf(paths["vip"], vip_prices, vip_signals, global_data, today_str)
    print(f"✓ VIP report: {paths['vip']}")

    paths["wildcard"] = f"{OUTPUT_DIR}/vektor_wildcard_{DATE_SLUG}.pdf"
    build_wildcard_pdf(paths["wildcard"], wildcard_prices, wildcard_signals, today_str)
    print(f"✓ Wild Card report: {paths['wildcard']}")

    paths["standard"] = f"{OUTPUT_DIR}/vektor_standard_{DATE_SLUG}.pdf"
    build_standard_pdf(paths["standard"], standard_prices, standard_signals, global_data, today_str)
    print(f"✓ Standard report: {paths['standard']}")

    paths["macro"] = f"{OUTPUT_DIR}/vektor_macro_{DATE_SLUG}.pdf"
    build_macro_pdf(paths["macro"], vip_prices, global_data, today_str)
    print(f"✓ Macro report: {paths['macro']}")

    return paths

# ── STEP 5: FETCH SUBSCRIBERS FROM SUPABASE ─────────────────────────────────────
def get_subscribers() -> dict:
    """
    Returns dict of tier -> list of subscriber emails.
    Supabase table: subscribers(email, tier, active, stripe_customer_id)
    Tiers: 'vip', 'standard', 'wildcard', 'all_access'
    """
    sb = create_client(SUPABASE_URL, SUPABASE_KEY)
    result = sb.table("subscribers").select("email,tier").eq("active", True).execute()
    
    tiers = {"vip": [], "standard": [], "wildcard": [], "all_access": []}
    for row in result.data:
        t = row["tier"]
        if t in tiers:
            tiers[t].append(row["email"])
    return tiers

# ── STEP 6: EMAIL DELIVERY VIA RESEND ──────────────────────────────────────────
def send_emails(subscribers: dict, pdf_paths: dict):
    resend.api_key = RESEND_KEY

    # Map: which tiers get which reports
    delivery_map = {
        "vip":        ["vip", "wildcard", "standard", "macro"],
        "all_access": ["vip", "wildcard", "standard", "macro"],
        "standard":   ["standard", "macro"],
        "wildcard":   ["wildcard"],
    }

    report_labels = {
        "vip":      "★ VIP Large Cap Signals",
        "wildcard": "🃏 Wild Card Speculative Signals",
        "standard": "📊 Standard Daily Signals",
        "macro":    "🌐 Macro Market Report",
    }

    for tier, emails in subscribers.items():
        if not emails:
            continue
        reports = delivery_map.get(tier, [])
        report_names = ", ".join(report_labels[r] for r in reports)

        for email in emails:
            attachments = []
            for report_key in reports:
                path = pdf_paths.get(report_key)
                if path and os.path.exists(path):
                    with open(path, "rb") as f:
                        import base64
                        attachments.append({
                            "filename": os.path.basename(path),
                            "content":  base64.b64encode(f.read()).decode(),
                        })

            resend.Emails.send({
                "from":    FROM_EMAIL,
                "to":      email,
                "subject": f"Vektor Signals — {TODAY}",
                "html":    build_email_html(tier, report_names, TODAY),
                "attachments": attachments,
            })
            print(f"  ✓ Sent to {email} ({tier})")

def build_email_html(tier: str, report_names: str, date: str) -> str:
    tier_label = "VIP Member" if tier in ("vip", "all_access") else "Member"
    return f"""
    <div style="background:#080612;color:#fff;font-family:sans-serif;padding:40px;max-width:600px;margin:auto;border-radius:12px;">
      <div style="margin-bottom:24px;">
        <span style="color:#F5C842;font-size:22px;font-weight:700;">VEKTOR</span>
        <span style="color:#fff;font-size:22px;font-weight:700;"> SIGNALS</span>
        {'<span style="background:#1C1530;color:#FFD700;font-size:11px;padding:3px 10px;border-radius:20px;margin-left:10px;">★ VIP</span>' if 'vip' in tier else ''}
      </div>
      <p style="color:#9A94B8;margin-bottom:8px;">{date}</p>
      <h2 style="color:#fff;margin-bottom:4px;">Your daily signals are ready.</h2>
      <p style="color:#6E688A;font-size:14px;margin-bottom:24px;">
        Today's reports are attached to this email: <strong style="color:#4DC3FF;">{report_names}</strong>
      </p>
      <div style="background:#0F0C1E;border:1px solid #2A2240;border-radius:8px;padding:16px;margin-bottom:24px;">
        <p style="color:#F5C842;font-weight:700;margin:0 0 8px;">⚠️ Risk Reminder</p>
        <p style="color:#6E688A;font-size:13px;margin:0;">
          All Vektor signals are AI-assisted market analysis for educational purposes only. 
          Never risk more than 1% per trade (0.5% for Wild Card picks). 
          Always use stop losses. Past performance does not guarantee future results.
        </p>
      </div>
      <p style="color:#6E688A;font-size:12px;text-align:center;">
        Vektor Signals · vektorsignals.com<br>
        <a href="{{{{unsubscribe}}}}" style="color:#7B2FBE;">Unsubscribe</a>
      </p>
    </div>
    """

# ── MAIN ────────────────────────────────────────────────────────────────────────
def main():
    print(f"\n{'='*50}")
    print(f"VEKTOR SIGNAL ENGINE — {TODAY}")
    print(f"{'='*50}\n")

    print("📡 Fetching market data...")
    vip_prices      = fetch_prices(VIP_COINS)
    wildcard_prices = fetch_prices(WILDCARD_COINS)
    standard_prices = fetch_prices(STANDARD_COINS)
    global_data     = fetch_global_data()
    print(f"  ✓ {len(vip_prices) + len(wildcard_prices)} prices fetched")

    print("\n🤖 Generating AI signal copy...")
    vip_signals      = generate_signals_ai("VIP Large Cap",   vip_prices,      global_data)
    wildcard_signals = generate_signals_ai("Wild Card Speculative", wildcard_prices, global_data)
    standard_signals = generate_signals_ai("Standard Daily",  standard_prices, global_data)
    print("  ✓ Signal copy generated")

    print("\n📄 Building PDFs...")
    pdf_paths = build_all_pdfs(
        vip_prices, wildcard_prices, standard_prices,
        vip_signals, wildcard_signals, standard_signals,
        global_data, TODAY
    )

    print("\n👥 Fetching subscribers...")
    subscribers = get_subscribers()
    total = sum(len(v) for v in subscribers.values())
    print(f"  ✓ {total} active subscribers found")
    for tier, emails in subscribers.items():
        print(f"     {tier}: {len(emails)}")

    print("\n📧 Sending emails...")
    send_emails(subscribers, pdf_paths)

    print(f"\n✅ VEKTOR ENGINE COMPLETE — {TODAY}\n")

if __name__ == "__main__":
    main()
