"""
VEKTOR SIGNALS — Stripe Webhook Handler
Deploy this as a Netlify Function or Vercel serverless function.
File path: netlify/functions/stripe-webhook.js (JS version below)

This Python version is for reference. Use the JS version for Netlify.
"""

# ================================================================
# NETLIFY FUNCTION (JavaScript) — Copy this to your Netlify repo
# Save as: netlify/functions/stripe-webhook.js
# ================================================================

NETLIFY_FUNCTION = """
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// Map Stripe Price IDs to Vektor tiers
// Replace these with your actual Stripe Price IDs
const PRICE_TO_TIER = {
  'price_STANDARD_MONTHLY_ID': 'standard',
  'price_STANDARD_ANNUAL_ID':  'standard',
  'price_VIP_MONTHLY_ID':      'vip',
  'price_VIP_ANNUAL_ID':       'vip',
};

exports.handler = async (event) => {
  const sig = event.headers['stripe-signature'];
  let stripeEvent;

  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature failed:', err.message);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  const { type, data } = stripeEvent;
  console.log('Stripe event:', type);

  // ── PAYMENT SUCCEEDED → Activate subscriber ──────────────────
  if (type === 'checkout.session.completed') {
    const session = data.object;
    const email   = session.customer_details?.email;
    const priceId = session.line_items?.data?.[0]?.price?.id;
    const tier    = PRICE_TO_TIER[priceId] || 'standard';
    const customerId = session.customer;
    const subId      = session.subscription;

    if (email) {
      const { error } = await supabase
        .from('subscribers')
        .upsert({
          email,
          tier,
          active: true,
          stripe_customer_id: customerId,
          stripe_sub_id: subId,
          cancelled_at: null,
        }, { onConflict: 'email' });

      if (error) console.error('Supabase upsert error:', error);
      else console.log(`✅ Activated ${tier} for ${email}`);
    }
  }

  // ── SUBSCRIPTION CANCELLED → Deactivate ──────────────────────
  if (type === 'customer.subscription.deleted') {
    const sub = data.object;
    const { error } = await supabase
      .from('subscribers')
      .update({ active: false, cancelled_at: new Date().toISOString() })
      .eq('stripe_sub_id', sub.id);

    if (error) console.error('Deactivation error:', error);
    else console.log(`❌ Deactivated subscription ${sub.id}`);
  }

  // ── PAYMENT FAILED → Flag subscriber ─────────────────────────
  if (type === 'invoice.payment_failed') {
    const invoice = data.object;
    const customerId = invoice.customer;
    const { error } = await supabase
      .from('subscribers')
      .update({ active: false })
      .eq('stripe_customer_id', customerId);

    if (error) console.error('Payment failed update error:', error);
    else console.log(`⚠️ Payment failed for customer ${customerId}`);
  }

  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};
"""

# Write the JS file
import os
os.makedirs("netlify/functions", exist_ok=True)
with open("netlify/functions/stripe-webhook.js", "w") as f:
    f.write(NETLIFY_FUNCTION.strip())

print("Netlify function written.")
